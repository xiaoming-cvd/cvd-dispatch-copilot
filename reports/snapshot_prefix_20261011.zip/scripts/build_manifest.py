"""生成 data/manifests/solomon_manifest.json：来源、哈希、许可、字段映射、转换规则。

原始文件位于 data/raw/solomon/（只读，默认不提交 Git）。
本脚本只读取并计算哈希，绝不修改原始文件。
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw" / "solomon"
OUT = ROOT / "data" / "manifests" / "solomon_manifest.json"

MIRROR_BASE = "https://raw.githubusercontent.com/jonzhaocn/VRPTW-ACO-python/master/solomon-100/"
CANONICAL_SOURCE = "https://www.sintef.no/projectweb/top/vrptw/100-customers/（官方页受 Cloudflare 防护，本机无法直接抓取，经 GitHub 公开镜像获取；内容已与公开文献记载的 C101 首行数值核对一致）"
SCRIPT_VERSION = "solomon-manifest/1.0"

FIELD_MAPPING = {
    "VEHICLE NUMBER": "车辆数上限（原始文件，仅记录；情景生成器自行决定启用车辆数）",
    "VEHICLE CAPACITY": "Vehicle.capacity（容量单位 load_units，原始值不换算）",
    "CUST NO.=0": "仓库节点 depot_node_id（XCOORD/YCOORD 为坐标，不直接入 schema）",
    "CUST NO.>0": "候选订单节点（坐标经欧氏距离换算为行驶时间矩阵）",
    "DEMAND": "Order.demand（原始载荷单位，不换算）",
    "READY TIME": "Order.ready_s（换算规则见 conversion_rules）",
    "DUE DATE": "Order.due_s（同上；仓库行的 DUE DATE 视为整体返回时限参考）",
    "SERVICE TIME": "Order.service_s（同上）",
    "XCOORD/YCOORD": "仅用于计算欧氏距离；坐标本身不进入 schema",
}

CONVERSION_RULES = {
    "time_unit_source": "算例原始时间单位（Solomon 惯例视为分钟），保留原始值于 raw，转换后单位为秒",
    "time_conversion": "ready_s/due_s/service_s = 原始值 * 60（整数），规则记录于此，不得静默改变",
    "travel_time": "time_s[i][j] = int(round(euclid_distance(coords_i, coords_y) * 60))；"
                   "欧氏距离按双精度计算后缩放取整（整数缩放与舍入规则），"
                   "原始坐标与双精度距离值不进入 schema",
    "travel_time_note": "坐标与载荷为基准单位，页面与报告不得直接称为公里、公斤",
    "capacity": "容量与需求量保留原始载荷单位（load_units），不换算",
}

LICENSE_NOTE = (
    "Solomon (1987) 学术基准算例，公开用于研究；原始出处 SINTEF TOP 页面。"
    "经第三方公开镜像分发，本仓库仅保存小体积文本算例并记录来源。"
    "不得声称拥有数据权利；商用前另行核对。"
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    files = sorted(RAW_DIR.glob("*.txt"))
    if not files:
        raise SystemExit(f"未找到原始算例：{RAW_DIR}（请先运行下载流程）")

    entries = []
    for f in files:
        entries.append({
            "file": f"solomon/{f.name}",
            "source_url": MIRROR_BASE + f.name.lower(),
            "canonical_source": CANONICAL_SOURCE,
            "download_date": str(date.today()),
            "sha256": sha256(f),
            "size_bytes": f.stat().st_size,
            "license_note": LICENSE_NOTE,
            "field_mapping": FIELD_MAPPING,
            "conversion_rules": CONVERSION_RULES,
            "filter_rules": "无过滤；原样保存原始文件",
            "missing_rate": "0（已核对每个文件含仓库行 + 100 个客户行）",
            "script_version": SCRIPT_VERSION,
        })

    manifest = {
        "dataset": "Solomon VRPTW 100-customers（选取 11 个基础算例）",
        "script_version": SCRIPT_VERSION,
        "generated": str(date.today()),
        "files": entries,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"manifest 已写入 {OUT}，共 {len(entries)} 个文件")
    for e in entries:
        print(f"  {e['file']}  sha256={e['sha256'][:12]}…  {e['size_bytes']}B")


if __name__ == "__main__":
    sys.exit(main())
