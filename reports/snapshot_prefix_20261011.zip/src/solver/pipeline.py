"""求解编排（任务书阶段 2）：方法调度 + 状态语义 + 独立复核。

状态判定规则（红线）：
- invalid_input：场景交叉校验未过；
- feasible：方法给出方案，且方案通过独立校验器复核；
- no_feasible_found：求解器超时/未找到解，或求解器声称有解但
  未通过独立复核（不采信求解器标志）——超时绝不等同"证明无解"；
- proven_infeasible：仅当 OR-Tools 明确返回 INFEASIBLE；
- error：编排层自身异常（输入文件损坏、建模失败等）。
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from ..domain.models import (
    RouteResult,
    Scenario,
    SolveResult,
    SolveStatus,
    StopSchedule,
    input_hash,
)
from ..validation.checks import validate_scenario
from ..validation.timetable import (
    SolutionValidation,
    evaluate_route,
    validate_solution,
)
from . import diff as diff_mod
from . import insert as insert_mod
from . import low_disruption as low_mod
from . import rebuild as rebuild_mod
from .copt_core import SOLVER_VERSION_COPT
from .ortools_core import SOLVER_VERSION

METHODS = ("insert", "rebuild", "low_disruption")


def _solver_version(method: str) -> str:
    if method == "rebuild":
        return SOLVER_VERSION_COPT
    if method == "low_disruption":
        return "stage3-low-disruption/1.0"
    return "stage2-insert-enum/1.0"


@dataclass(frozen=True)
class SolveOutcome:
    result: SolveResult
    validation: SolutionValidation | None  # None = 未走到独立复核


def _metrics(scn: Scenario, routes: list[RouteResult]) -> dict:
    travel = 0
    wait = 0
    max_return = 0
    for r in routes:
        ev = evaluate_route(scn, r.vehicle_id, list(r.order_ids))
        travel += ev.travel_time_s
        wait += sum(s.wait_s for s in ev.stops)
        max_return = max(max_return, ev.return_s)
    return {
        "total_travel_time_s": travel,
        "total_wait_s": wait,
        "vehicles_used": len(routes),
        "orders_served": sum(len(r.order_ids) for r in routes),
        "orders_total": len(scn.orders),
        "max_return_s": max_return,
    }


def _assemble(
    scn: Scenario,
    method: str,
    time_limit_ms: int,
    started: float,
    status: SolveStatus,
    routes: list[RouteResult],
    validation: SolutionValidation | None,
    warnings: list[str],
    assumptions: list[str],
    extra_metrics: dict | None = None,
) -> SolveResult:
    schedule: list[StopSchedule] = []
    if validation is not None:
        for ev in validation.routes:
            schedule.extend(ev.stops)
    metrics = _metrics(scn, routes) if routes else {}
    if extra_metrics:
        metrics.update(extra_metrics)
    return SolveResult(
        input_hash=input_hash(scn),
        config={"method": method, "time_limit_ms": time_limit_ms},
        solver_version=_solver_version(method),
        elapsed_ms=int((time.monotonic() - started) * 1000),
        status=status,
        routes=routes,
        schedule=schedule,
        metrics=metrics,
        validation=validation.to_dict() if validation else {},
        warnings=warnings,
        assumptions=assumptions,
    )


def solve(
    scn: Scenario,
    method: str,
    time_limit_ms: int = 10_000,
) -> SolveOutcome:
    """对一个完整场景跑一种基线方法，返回规范 SolveResult。"""
    started = time.monotonic()
    if method not in METHODS:
        raise ValueError(f"E_METHOD: 未知方法 {method}，可选 {METHODS}")

    report = validate_scenario(scn)
    if not report.ok:
        result = _assemble(
            scn, method, time_limit_ms, started, SolveStatus.INVALID_INPUT,
            [], None, [], [],
            extra_metrics={"input_issues": [i.to_dict() for i in report.issues]},
        )
        return SolveOutcome(result=result, validation=None)

    assumptions = [
        "车辆从仓库固定时刻 available_from_s 出发，服务开始=max(到达,ready_s)，"
        "等待=服务开始-到达；返回不得晚于 return_by_s",
        "容量为配送语义：单路线装载=路线全部订单 demand 之和",
        "可行性由独立校验器依据输入矩阵重算复核，不采信求解器标志",
    ]

    warnings: list[str] = []

    try:
        if method == "insert":
            routes, diag = insert_mod.insert_new_orders(scn)
            if not routes:
                result = _assemble(
                    scn, method, time_limit_ms, started,
                    SolveStatus.NO_FEASIBLE_FOUND, [], None,
                    warnings=["插单基线未找到可行插入位置（枚举未覆盖搬动旧任务，"
                              "不代表问题被证明无解，可尝试 rebuild 方法）"],
                    assumptions=assumptions,
                    extra_metrics={"diagnostics": diag},
                )
                return SolveOutcome(result=result, validation=None)
            extra = {"diagnostics": diag}
        elif method == "rebuild":
            outcome = rebuild_mod.rebuild_all(scn, time_limit_ms)
            served = [oid for seq in outcome.routes for oid in seq]
            expected = sorted(o.order_id for o in scn.orders)
            if outcome.raw_status in ("ROUTING_INFEASIBLE", "MIP_INFEASIBLE"):
                result = _assemble(
                    scn, method, time_limit_ms, started,
                    SolveStatus.PROVEN_INFEASIBLE, [], None,
                    warnings=[f"求解器证明无可行解（{outcome.raw_status}）"],
                    assumptions=assumptions,
                    extra_metrics={"solver_status": outcome.raw_status},
                )
                return SolveOutcome(result=result, validation=None)
            if outcome.raw_status not in (
                    "ROUTING_SUCCESS", "ROUTING_OPTIMAL",
                    "ROUTING_PARTIAL_SUCCESS_LOCAL_OPTIMUM_NOT_REACHED",
                    "MIP_OPTIMAL", "MIP_TIMEOUT_WITH_SOL") \
                    or sorted(served) != expected:
                reason = (
                    f"求解器状态 {outcome.raw_status} 或方案未覆盖全部订单"
                    f"（served={len(served)}/{len(expected)}）；"
                    "未找到可行解 ≠ 证明无解"
                )
                result = _assemble(
                    scn, method, time_limit_ms, started,
                    SolveStatus.NO_FEASIBLE_FOUND, [], None,
                    warnings=[reason], assumptions=assumptions,
                    extra_metrics={"solver_status": outcome.raw_status},
                )
                return SolveOutcome(result=result, validation=None)
            routes = rebuild_mod.outcome_to_routes(scn, outcome)
            extra = {"solver_status": outcome.raw_status}
        if method == "low_disruption":
            outcome = low_mod.solve_low_disruption(scn, time_limit_ms)
            if outcome.recommended is None:
                result = _assemble(
                    scn, method, time_limit_ms, started,
                    SolveStatus.NO_FEASIBLE_FOUND, [], None,
                    warnings=["低扰动方法未找到任何可行候选（插单种子与"
                              "单任务搬动种子均失败），不代表问题被证明无解，"
                              "可尝试 rebuild 方法"],
                    assumptions=assumptions,
                    extra_metrics={"diagnostics": outcome.diagnostics},
                )
                return SolveOutcome(result=result, validation=None)
            routes = list(outcome.recommended.routes)
            low = outcome.recommended
            best = outcome.best_cost_candidate
            extra = {
                "diagnostics": outcome.diagnostics,
                "recommended_candidate": low.summary(),
                "best_cost_candidate": best.summary() if best else None,
                "candidates": [c.summary() for c in outcome.candidates],
                "candidate_count": len(outcome.candidates),
            }
            warnings = []
            if len(outcome.candidates) < 2:
                warnings.append(
                    "可行候选不足两个不同方案，仅展示唯一候选；"
                    "低扰动选择在单候选内退化为该候选本身")
            assumptions = assumptions + [
                f"低扰动候选成本上限 = {low_mod.COST_CAP:.2f} × 候选池最低总行驶时间"
                "（COST_CAP，可调）",
                "best_cost 仅来自本方法自己的候选池，不代表全局最优",
                "低扰动方法不调用 COPT/OR-Tools 子求解，"
                "本结果总耗时即该方法端到端耗时",
            ]
    except Exception as exc:  # noqa: BLE001 — 编排层兜底，状态语义要求
        result = _assemble(
            scn, method, time_limit_ms, started, SolveStatus.ERROR, [],
            None, warnings=[f"{type(exc).__name__}: {exc}"], assumptions=[],
        )
        return SolveOutcome(result=result, validation=None)

    # 独立复核（红线）：求解器结果一律重算校验
    validation = validate_solution(scn, routes)
    if not validation.ok:
        result = _assemble(
            scn, method, time_limit_ms, started,
            SolveStatus.NO_FEASIBLE_FOUND, [], validation,
            warnings=["求解器返回的方案未通过独立校验，按未找到可行解处理，"
                      "详见 validation.issues"], assumptions=assumptions,
        )
        return SolveOutcome(result=result, validation=validation)

    result = _assemble(
        scn, method, time_limit_ms, started, SolveStatus.FEASIBLE,
        routes, validation, warnings, assumptions, extra_metrics=extra,
    )
    if method == "low_disruption":
        result = result.model_copy(
            update={"diff": diff_mod.diff_orders(scn, routes)})
    return SolveOutcome(result=result, validation=validation)
