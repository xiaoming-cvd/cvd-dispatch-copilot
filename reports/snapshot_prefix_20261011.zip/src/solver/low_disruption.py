"""低扰动重排（任务书阶段 3）：候选生成 + 选择规则 + 逐任务 diff。

算法（与执行清单口径一致）：
- 不调用 COPT/OR-Tools 子求解，总耗时即本方法端到端耗时；
- 候选来源：(a) 插单基线结果；(b) 插单失败时的单旧任务搬动枚举种子；
  (c) 尊重锁定的 relocate/swap 局部搜索（可行状态才进档案）；
- 可行性判定全部来自独立重算（src/validation/timetable.py），不采信任何
  求解器标志；扰动指标定义见 src/solver/perturbation.py。

候选选择规则（任务书/执行清单）：
- best_cost = 候选池中总行驶时间最低者（仅来自本方法自己的候选，不声称
  全局最优）；
- 低扰动候选 = 总行驶时间 ≤ 1.10 × best_cost 的候选中，
  按 (换车数, 相邻破坏数, 成本) 字典序最小者；
- 候选不足两个不同可行解时如实展示并给出 warning。
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from ..domain.models import RouteResult, Scenario
from ..validation.timetable import evaluate_route
from . import insert as insert_mod
from . import perturbation as pert_mod

COST_CAP = 1.10  # 低扰动候选的成本上限（相对候选池最优，可调）


@dataclass(frozen=True)
class Candidate:
    key: tuple  # 规范化键：tuple(sorted((vid, tuple(seq))))
    routes: tuple[RouteResult, ...]
    total_travel_s: int
    perturbation: pert_mod.Perturbation

    def summary(self) -> dict:
        return {
            "total_travel_time_s": self.total_travel_s,
            "vehicle_changes": self.perturbation.vehicle_changes,
            "adjacency_breaks": self.perturbation.adjacency_breaks,
        }


@dataclass(frozen=True)
class LowDisruptionOutcome:
    recommended: Candidate | None          # 默认推荐 = 低扰动候选
    candidates: tuple[Candidate, ...]      # 全部可行候选（含推荐）
    best_cost_candidate: Candidate | None  # 成本最低候选
    diagnostics: dict


# ---- 基础工具 ----

def _initial_sequences(scn: Scenario) -> dict[str, list[str]]:
    seqs: dict[str, list[str]] = {
        r.vehicle_id: list(r.order_ids) for r in scn.original_plan.routes}
    for v in scn.vehicles:  # 原计划未用到的车也参与
        seqs.setdefault(v.vehicle_id, [])
    return seqs


def _key(seqs: dict[str, list[str]]) -> tuple:
    return tuple(sorted((vid, tuple(seq)) for vid, seq in seqs.items() if seq))


def _evaluate(
    scn: Scenario, seqs: dict[str, list[str]]
) -> tuple[tuple[RouteResult, ...], int] | None:
    """独立重算：逐路线 evaluate_route + 覆盖性（恰好全部订单各一次）。

    返回 (routes, total_travel_s)；任何路线不可行或覆盖不完整返回 None。
    """
    routes: list[RouteResult] = []
    total = 0
    for vid, seq in seqs.items():
        if not seq:
            continue
        ev = evaluate_route(scn, vid, list(seq))
        if not ev.ok:
            return None
        routes.append(RouteResult(
            vehicle_id=vid, order_ids=tuple(seq), return_s=ev.return_s))
        total += ev.travel_time_s
    served = sorted(o for r in routes for o in r.order_ids)
    expected = sorted(o.order_id for o in scn.orders)
    if served != expected:
        return None
    return tuple(routes), total


def _greedy_insert(
    scn: Scenario, seqs: dict[str, list[str]], new_order_ids: list[str]
) -> dict[str, list[str]] | None:
    """在给定旧序列上贪心插入新任务（同插单基线规则），失败返回 None。"""
    work = {vid: list(seq) for vid, seq in seqs.items()}
    for oid in new_order_ids:
        best: tuple[int, str, int] | None = None
        base = {}
        for vid, seq in work.items():
            if not seq:
                base[vid] = 0  # 空路线：只有新任务时的行驶时间
                ev = evaluate_route(scn, vid, [oid])
                if ev.ok:
                    best = (ev.travel_time_s, vid, 0) if best is None \
                        else min(best, (ev.travel_time_s, vid, 0))
                continue
            ev0 = evaluate_route(scn, vid, list(seq))
            if not ev0.ok:
                continue
            base[vid] = ev0.travel_time_s
            for pos in range(len(seq) + 1):
                cand = seq[:pos] + [oid] + seq[pos:]
                ev = evaluate_route(scn, vid, cand)
                if not ev.ok:
                    continue
                delta = ev.travel_time_s - base[vid]
                if best is None or delta < best[0]:
                    best = (delta, vid, pos)
        if best is None:
            return None
        _, vid, pos = best
        work[vid] = work[vid][:pos] + [oid] + work[vid][pos:]
    return work


# ---- 锁定约束下的可移动性 ----

def _movable(scn: Scenario, oid: str) -> bool:
    """相对顺序锁成员一律禁止移动。"""
    for lock in scn.locks.relative_order_locks:
        if oid in lock.order_ids:
            return False
    return True


def _allowed_vehicles(scn: Scenario, oid: str) -> set[str]:
    """换车锁任务只允许在锁定车内移动；其余任务可去任何车。"""
    locked_to = scn.locks.assignment_locks.get(oid)
    if locked_to is not None:
        return {locked_to}
    return {v.vehicle_id for v in scn.vehicles}


# ---- 候选生成 ----

def _archive_candidate(
    scn: Scenario,
    seqs: dict[str, list[str]],
    archive: dict[tuple, Candidate],
) -> Candidate | None:
    key = _key(seqs)
    if key in archive:
        return archive[key]
    evaled = _evaluate(scn, seqs)
    if evaled is None:
        return None
    routes, total = evaled
    cand = Candidate(
        key=key, routes=routes, total_travel_s=total,
        perturbation=pert_mod.measure(scn, routes),
    )
    archive[key] = cand
    return cand


def _seed_candidates(
    scn: Scenario, archive: dict[tuple, Candidate], diagnostics: dict
) -> None:
    """种子：插单基线；失败则单旧任务搬动枚举后重试插单。"""
    new_ids = [o.order_id for o in scn.orders if o.is_new]

    routes, diag = insert_mod.insert_new_orders(scn)
    diagnostics["insert_seed"] = diag
    if routes:
        seqs = _initial_sequences(scn)
        for r in routes:
            seqs[r.vehicle_id] = list(r.order_ids)
        _archive_candidate(scn, seqs, archive)
        return

    # 插单失败：枚举"搬动一个旧任务"（换车或车内换位）后再插单
    diagnostics["relocate_seed"] = {"tried": 0, "seeds_found": 0}
    base = _initial_sequences(scn)
    for oid in [o.order_id for o in scn.orders if not o.is_new]:
        if not _movable(scn, oid):
            continue
        home = next(vid for vid, seq in base.items() if oid in seq)
        if not new_ids:  # 无新任务时插单必"成功"，到不了这里；防御
            continue
        for vid in sorted(_allowed_vehicles(scn, oid)):
            for pos in range(len(base[vid]) + (0 if vid == home else 1)):
                seqs = {v: list(s) for v, s in base.items()}
                seqs[home].remove(oid)
                seqs[vid] = seqs[vid][:pos] + [oid] + seqs[vid][pos:]
                diagnostics["relocate_seed"]["tried"] += 1
                grown = _greedy_insert(scn, seqs, new_ids)
                if grown is None:
                    continue
                cand = _archive_candidate(scn, grown, archive)
                if cand is not None:
                    diagnostics["relocate_seed"]["seeds_found"] += 1


def _neighbors(
    scn: Scenario, seqs: dict[str, list[str]]
) -> list[dict[str, list[str]]]:
    """relocate + swap 邻域（尊重锁定；新任务也可 relocate，只影响成本）。"""
    out: list[dict[str, list[str]]] = []
    movable_old = [o.order_id for o in scn.orders
                   if not o.is_new and _movable(scn, o.order_id)]
    new_ids = [o.order_id for o in scn.orders if o.is_new]

    # relocate：旧任务（换车/换位）与新任务（只影响成本，不违反"新任务无原车"）
    for oid in movable_old + new_ids:
        home = next(vid for vid, seq in seqs.items() if oid in seq)
        targets = (sorted(_allowed_vehicles(scn, oid))
                   if oid in movable_old else sorted(seqs))
        for vid in targets:
            dst = seqs.get(vid, [])  # 候选中未启用的车视为空路线
            for pos in range(len(dst) + (0 if vid == home else 1)):
                src = seqs[home]
                cur = src.index(oid)
                if vid == home and (pos == cur or pos == cur + 1):
                    continue  # 原位或等效原位
                cand = {v: list(s) for v, s in seqs.items()}
                cand[home].remove(oid)
                cand[vid] = cand.get(vid, [])[:pos] + [oid] + cand.get(vid, [])[pos:]
                out.append(cand)

    # swap：两个可移动旧任务互换（新任务不参与，避免无意义组合爆炸）
    for i, a in enumerate(movable_old):
        va = next(vid for vid, seq in seqs.items() if a in seq)
        ia = seqs[va].index(a)
        for b in movable_old[i + 1:]:
            if b not in _allowed_vehicles(scn, a) and \
                    scn.locks.assignment_locks.get(a) is not None:
                continue
            if a not in _allowed_vehicles(scn, b) and \
                    scn.locks.assignment_locks.get(b) is not None:
                continue
            vb = next(vid for vid, seq in seqs.items() if b in seq)
            ib = seqs[vb].index(b)
            cand = {v: list(s) for v, s in seqs.items()}
            cand[va][ia], cand[vb][ib] = b, a
            # swap 后检查锁定车约束仍然成立（互换可能把车锁任务带出锁定车）
            if scn.locks.assignment_locks.get(a, va) != va or \
                    scn.locks.assignment_locks.get(b, vb) != vb:
                continue
            out.append(cand)
    return out


def _local_search(
    scn: Scenario,
    archive: dict[tuple, Candidate],
    time_limit_ms: int,
    started: float,
    diagnostics: dict,
) -> None:
    """从当前候选出发迭代扩展邻域，直到时间预算耗尽或邻域无可行新解。"""
    stats = {"iterations": 0, "evaluated": 0}
    diagnostics["local_search"] = stats
    frontier = [c for c in archive.values()]
    seen = set(archive)
    while frontier and (time.monotonic() - started) * 1000 < time_limit_ms:
        stats["iterations"] += 1
        next_frontier: list[Candidate] = []
        for cand in frontier:
            seqs = {r.vehicle_id: list(r.order_ids) for r in cand.routes}
            for nb in _neighbors(scn, seqs):
                stats["evaluated"] += 1
                if (time.monotonic() - started) * 1000 >= time_limit_ms:
                    break
                key = _key(nb)
                if key in seen:
                    continue
                seen.add(key)
                evaled = _evaluate(scn, nb)
                if evaled is None:
                    continue
                routes, total = evaled
                new_cand = Candidate(
                    key=key, routes=routes, total_travel_s=total,
                    perturbation=pert_mod.measure(scn, routes),
                )
                archive[key] = new_cand
                next_frontier.append(new_cand)
        frontier = next_frontier


# ---- 选择规则 ----

def _select(
    candidates: list[Candidate], diagnostics: dict
) -> tuple[Candidate | None, Candidate | None]:
    if not candidates:
        return None, None
    best_cost = min(candidates, key=lambda c: (c.total_travel_s, c.key))
    cap = COST_CAP * best_cost.total_travel_s
    pool = [c for c in candidates if c.total_travel_s <= cap + 1e-9]
    low = min(pool, key=lambda c: (
        c.perturbation.vehicle_changes,
        c.perturbation.adjacency_breaks,
        c.total_travel_s, c.key,
    ))
    diagnostics["selection"] = {
        "best_cost_s": best_cost.total_travel_s,
        "cost_cap_s": round(cap, 3),
        "pool_size": len(pool),
        "candidates_total": len(candidates),
    }
    return low, best_cost


def solve_low_disruption(
    scn: Scenario, time_limit_ms: int = 10_000
) -> LowDisruptionOutcome:
    """入口：生成候选、局部搜索、按选择规则推荐。全程独立重算。"""
    started = time.monotonic()
    archive: dict[tuple, Candidate] = {}
    diagnostics: dict = {"time_limit_ms": time_limit_ms}
    _seed_candidates(scn, archive, diagnostics)
    if archive:
        remaining = time_limit_ms - int((time.monotonic() - started) * 1000)
        if remaining > 0:
            _local_search(scn, archive, remaining, started, diagnostics)
    candidates = sorted(archive.values(), key=lambda c: c.key)
    low, best = _select(list(candidates), diagnostics)
    diagnostics["elapsed_ms"] = int((time.monotonic() - started) * 1000)
    return LowDisruptionOutcome(
        recommended=low, candidates=tuple(candidates),
        best_cost_candidate=best, diagnostics=diagnostics,
    )
