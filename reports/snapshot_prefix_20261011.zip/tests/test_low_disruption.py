"""阶段 3 测试：低扰动重排、扰动指标、diff 与选择规则。

覆盖（对应 TODO 与任务书第 12 章）：
- 无新增任务：扰动为 0，diff 全部"车辆与相对位置未变"；
- 只插新任务：换车数=0、相邻破坏数=0，顺延不计扰动；
- 跨车场景：换车数只统计旧任务，新任务不参与；
- 锁保持：相对顺序锁成员不被移动，换车锁任务不离开锁定车；
- 选择规则：成本 ≤ 1.10 × 候选最优内按 (换车, 相邻破坏, 成本) 取最小；
- diff 变更原因全部来自固定取值集合。
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from src.domain.models import (
    Locks,
    Order,
    OriginalPlan,
    RelativeOrderLock,
    RoutePlan,
    RouteResult,
    Scenario,
    SolveStatus,
    TravelMatrix,
    Vehicle,
)
from src.solver import diff as diff_mod
from src.solver import low_disruption as low_mod
from src.solver import perturbation as pert_mod
from src.solver.pipeline import solve
from src.validation.timetable import validate_solution

ROOT = Path(__file__).resolve().parent.parent
SAMPLE = json.loads((ROOT / "data" / "sample" / "sample_small.json").read_text(encoding="utf-8"))
SCN = Scenario(**SAMPLE["scenario"])


def _scn(orders, vehicles, matrix, routes, locks=None):
    return Scenario(
        scenario_id="t3", version=1, time_origin=SCN.time_origin,
        capacity_unit="load_units", depot_node_id="depot",
        orders=orders, vehicles=vehicles, travel_matrix=matrix,
        original_plan=OriginalPlan(
            plan_id="p0", version=1,
            routes=[RoutePlan(vehicle_id=v, order_ids=tuple(o)) for v, o in routes]),
        locks=locks or Locks(),
    )


def _base(vehicle_extra=None, lock=None):
    """V1: o1→o2（A→B），V2: o3（C）；矩阵 depot/A/B/C。"""
    orders = [
        Order(order_id="o1", node_id="A", demand=1, ready_s=0, due_s=5000, service_s=60),
        Order(order_id="o2", node_id="B", demand=1, ready_s=0, due_s=5000, service_s=60),
        Order(order_id="o3", node_id="C", demand=1, ready_s=0, due_s=5000, service_s=60),
    ]
    vehicles = [Vehicle(vehicle_id="V1", capacity=10, available_from_s=0,
                        return_by_s=20000),
                Vehicle(vehicle_id="V2", capacity=10, available_from_s=0,
                        return_by_s=20000)]
    if vehicle_extra:
        vehicles = vehicle_extra(vehicles)
    matrix = TravelMatrix(node_ids=["depot", "A", "B", "C"], time_s=[
        [0, 300, 400, 500],
        [300, 0, 200, 250],
        [400, 200, 0, 200],
        [500, 250, 200, 0],
    ])
    return _scn(orders, vehicles, matrix,
                [("V1", ["o1", "o2"]), ("V2", ["o3"])], locks=lock)


def _routes(scn, mapping):
    """mapping: {vehicle_id: [order_ids]} → RouteResult 列表。"""
    from src.validation.timetable import evaluate_route
    out = []
    for vid, seq in mapping.items():
        ev = evaluate_route(scn, vid, seq)
        out.append(RouteResult(vehicle_id=vid, order_ids=tuple(seq),
                               return_s=ev.return_s))
    return out


class TestPerturbationMetric:
    def test_no_new_orders_zero_perturbation(self):
        scn = _base()
        p = pert_mod.measure(scn, _routes(scn, {"V1": ["o1", "o2"], "V2": ["o3"]}))
        assert p.vehicle_changes == 0
        assert p.adjacency_breaks == 0

    def test_insertion_shift_does_not_break_adjacency(self):
        # o4 新任务插到 o1、o2 之间：滤去新任务后 o1→o2 仍相邻 → 0 破坏
        orders = list(SCN.orders)  # 占位不用
        scn = _base()
        new = scn.orders[2].model_copy(update={"order_id": "o4", "node_id": "A",
                                               "is_new": True})
        scn2 = scn.model_copy(update={"orders": tuple(list(scn.orders) + [new])})
        p = pert_mod.measure(scn2, _routes(scn2, {"V1": ["o1", "o4", "o2"], "V2": ["o3"]}))
        assert p.vehicle_changes == 0
        assert p.adjacency_breaks == 0

    def test_vehicle_change_counts_only_old(self):
        # o3 换到 V1，新任务 o4 放在 V2（"换车"不算 o4 的）
        scn = _base()
        new = scn.orders[2].model_copy(update={"order_id": "o4", "node_id": "A",
                                               "is_new": True})
        scn2 = scn.model_copy(update={"orders": tuple(list(scn.orders) + [new])})
        p = pert_mod.measure(scn2, _routes(scn2, {"V1": ["o1", "o2", "o3"], "V2": ["o4"]}))
        assert p.vehicle_changes == 1  # 只有 o3
        # 原 V2 上只有 o3 单点，无相邻对；o1→o2 在 V1 仍相邻
        assert p.adjacency_breaks == 0

    def test_old_reorder_breaks_adjacency(self):
        scn = _base()
        p = pert_mod.measure(scn, _routes(scn, {"V1": ["o2", "o1"], "V2": ["o3"]}))
        assert p.adjacency_breaks == 1
        reasons = {s.pair: s.reason for s in p.adjacency_detail}
        assert reasons[("o1", "o2")] == "同车旧任务顺序被改变"


class TestDiff:
    REASONS = {
        "新增任务（原计划不存在）",
        "车辆与相对位置未变",
        "位置因新任务插入顺延（不计扰动）",
        "同车旧任务顺序改变",
    }

    def test_reasons_from_fixed_vocabulary(self):
        scn = _base()
        new = scn.orders[2].model_copy(update={"order_id": "o4", "node_id": "A",
                                               "is_new": True})
        scn2 = scn.model_copy(update={"orders": tuple(list(scn.orders) + [new])})
        d = diff_mod.diff_orders(scn2, _routes(scn2, {"V1": ["o1", "o4", "o2"], "V2": ["o3"]}))
        for oid, entry in d["orders"].items():
            assert entry["change_reason"] in self.REASONS | {"从 V1 换到 V2", "从 V2 换到 V1"}
        assert d["orders"]["o4"]["change_reason"] == "新增任务（原计划不存在）"
        assert d["orders"]["o2"]["change_reason"] == "位置因新任务插入顺延（不计扰动）"
        assert d["orders"]["o1"]["change_reason"] == "车辆与相对位置未变"
        assert d["orders"]["o3"]["change_reason"] == "车辆与相对位置未变"

    def test_no_new_orders_all_unchanged(self):
        scn = _base()
        d = diff_mod.diff_orders(scn, _routes(scn, {"V1": ["o1", "o2"], "V2": ["o3"]}))
        assert all(e["change_reason"] == "车辆与相对位置未变"
                   for e in d["orders"].values())
        assert d["perturbation"]["vehicle_changes"] == 0


class TestLowDisruptionSolve:
    def test_pipeline_feasible_and_validated(self):
        outcome = solve(SCN, "low_disruption", time_limit_ms=5000)
        assert outcome.result.status == SolveStatus.FEASIBLE
        assert outcome.validation is not None and outcome.validation.ok
        assert outcome.result.metrics["orders_served"] == 5

    def test_recommended_in_candidates_and_diff_present(self):
        outcome = solve(SCN, "low_disruption", time_limit_ms=5000)
        res = outcome.result
        assert res.diff["orders"], "diff 必须逐任务覆盖"
        assert "perturbation" in res.diff
        assert res.metrics["candidate_count"] >= 1
        assert res.metrics["recommended_candidate"]["vehicle_changes"] <= \
            res.metrics["best_cost_candidate"]["vehicle_changes"]

    def test_selection_cost_cap_respected(self):
        outcome = low_mod.solve_low_disruption(SCN, time_limit_ms=5000)
        if len(outcome.candidates) < 2:
            pytest.skip("候选不足两个，无法验证选择规则")
        best = outcome.best_cost_candidate
        low = outcome.recommended
        assert low.total_travel_s <= low_mod.COST_CAP * best.total_travel_s + 1e-9
        pool = [c for c in outcome.candidates
                if c.total_travel_s <= low_mod.COST_CAP * best.total_travel_s + 1e-9]
        expect = min(pool, key=lambda c: (c.perturbation.vehicle_changes,
                                          c.perturbation.adjacency_breaks,
                                          c.total_travel_s, c.key))
        assert low is expect

    def test_relative_order_lock_members_not_moved(self):
        # o1,o2 在 V1 上加相对顺序锁：推荐方案中二者仍在 V1 且 o1 先于 o2
        lock = Locks(relative_order_locks=[
            RelativeOrderLock(vehicle_id="V1", order_ids=["o1", "o2"])])
        scn = _base(lock=lock)
        new = scn.orders[1].model_copy(update={"order_id": "o4", "node_id": "C",
                                               "demand": 3, "is_new": True})
        scn2 = scn.model_copy(update={"orders": tuple(list(scn.orders) + [new])})
        outcome = solve(scn2, "low_disruption", time_limit_ms=3000)
        if outcome.result.status != SolveStatus.FEASIBLE:
            pytest.skip("该场景下未找到可行解，锁保持无从验证")
        seqs = {r.vehicle_id: list(r.order_ids) for r in outcome.result.routes}
        assert "o1" in seqs["V1"] and "o2" in seqs["V1"]
        assert seqs["V1"].index("o1") < seqs["V1"].index("o2")

    def test_assignment_lock_keeps_task_on_vehicle(self):
        # o3 换车锁在 V2：任何候选里 o3 都不得出现在 V1
        lock = Locks(assignment_locks={"o3": "V2"})
        scn = _base(lock=lock)
        new = scn.orders[1].model_copy(update={"order_id": "o4", "node_id": "A",
                                               "is_new": True})
        scn2 = scn.model_copy(update={"orders": tuple(list(scn.orders) + [new])})
        outcome = low_mod.solve_low_disruption(scn2, time_limit_ms=3000)
        for cand in outcome.candidates:
            seqs = {r.vehicle_id: list(r.order_ids) for r in cand.routes}
            assert "o3" in seqs.get("V2", []) or "o3" not in seqs.get("V1", [])
            assert "o3" not in seqs.get("V1", [])

    def test_every_candidate_passes_independent_validation(self):
        outcome = low_mod.solve_low_disruption(SCN, time_limit_ms=3000)
        assert outcome.candidates, "至少应有一个可行候选"
        for cand in outcome.candidates:
            assert validate_solution(SCN, list(cand.routes)).ok

    def test_no_feasible_is_not_proven_infeasible(self):
        # 新任务需求超过总容量：低扰动找不到候选，但绝不声称证明无解
        orders = [
            Order(order_id="o1", node_id="A", demand=5, ready_s=0, due_s=5000, service_s=60),
            Order(order_id="o2", node_id="B", demand=5, ready_s=0, due_s=5000, service_s=60,
                  is_new=True),
        ]
        vehicles = [Vehicle(vehicle_id="V1", capacity=6, available_from_s=0, return_by_s=20000)]
        matrix = TravelMatrix(node_ids=["depot", "A", "B"], time_s=[
            [0, 300, 400], [300, 0, 200], [400, 200, 0]])
        scn = _scn(orders, vehicles, matrix, [("V1", ["o1"])])
        outcome = solve(scn, "low_disruption", time_limit_ms=2000)
        assert outcome.result.status == SolveStatus.NO_FEASIBLE_FOUND
        assert outcome.result.status != SolveStatus.PROVEN_INFEASIBLE
