# docs/handoff.md — 阶段交接记录

## 当前状态：阶段 1 ✅ · 阶段 2 ✅ · 阶段 3 ✅ v2 复审修复完成（待总工复审）· 阶段 4 ✅（待验收，2026-10-11）

> 阶段 4"自然语言需求与人工确认"已交付（LLM 适配层 + 草案/确认接口 + 51 项中文需求测试
> 全过 + DeepSeek 真实模型脱敏冒烟）。本阶段不调用求解器、未经确认不生成新场景版本；
> 密钥只存本机 `.env`（gitignore 排除）/后端环境变量，全程未进仓库与产物。
> 逐项状态见 [review_closure](../reports/review_closure.md)；真实模型冒烟见
> [stage4_real_model](../reports/stage4_real_model.md)。

> 阶段验收口径按审查报告执行：P0 四项 + P1 四项全部"已修复且验证"（原生模型测试 +
> 穷举核对），但阶段 2/3 的正式通过以审查机复审为准，不在本机提前标绿。
> 逐项状态见 [review_closure](../reports/review_closure.md)。

> **阶段 3 v2（第二轮跨电脑复审，2026-10-11）**：复审结论"有条件通过"，P0-1（成本上限
> 改基于跨方法 `reference_best_cost`）+ P0-2（预算重复扣减改绝对截止）+ P1 六项
> （ratio 参数化、测试零 skip、候选可审计、输出瘦身、新任务可移入空闲车、规模上限）
> 已全部修复；P2 锁放松缓议记录。验证基线：全量 **201 passed, 0 failed, 0 skipped**
> （`reports/stage3_v2_pytest_log.txt`）；三方法对比两场景见 `reports/method_compare/`。
> 逐项关闭表见 [review_closure_stage3](../reports/review_closure_stage3.md)。

### 审查修正内容
1. **矩阵 0 值规则**（源码确认过度限制后修正）：非对角线 0 = 合法行驶时间（同址/取整），
   不再判缺边；缺边必须显式 null 表达，首版拒绝（E_MATRIX_EDGE_MISSING）。
   规则写入 `TravelMatrix` docstring，JSON Schema 表达为 integer|null。
2. **深冻结与哈希证据**（新增 `tests/test_immutability.py`，20+ 断言）：
   容器字段全部 tuple 化、锁/成本字典 FrozenDict 化（默认工厂同步），
   原地修改列表/字典现在真正抛错；哈希敏感性（矩阵/锁/计划/订单任改即变）、
   model_copy 冻结隔离（原计划对象与内容不变）、NaN/±inf（mode=before 统一
   E_NON_FINITE 拒绝）、容量/时间单位冲突（构造路径拒绝）全部有测试证据。
3. **布局感知划分**：坐标集合相同的算例整组划入同一集合（修复前 C2/R 布局组跨
   开发/测试——确认是真实缺陷，非仅记录）；新增 `tests/test_layout_split.py` 回归。
4. **执行清单补四点**：校验器分层（checks=输入结构 / timetable=路线可行性独立校验）、
   阶段验收记录表、阶段 3 预算口径（子求解耗时计入本方法总预算）、
   数据许可"链接+待确认"标注；×60 明确为模拟尺度转换。
5. 情景已按新划分重生成（17 个，registry 同步），tight 规则修正致 c101-s102 哈希变化（预期）。

- 全量测试：**111 passed**（`reports/stage0_review_fix_log.txt`）
- 日期：2026-10-11
- 代码版本：未建 Git 仓库（等队长指示）
- 项目根目录：`C:\Users\tianj\Desktop\城配调度副驾\`
- 说明：阶段 2 的骨架代码由并行会话产出，本会话完成收尾修复与 COPT 后端接入。

## 环境配置

| 项 | 值 | 验证 |
|---|---|---|
| Python | 3.12（venv 3.12.7） | ✅ |
| pydantic / pytest | 2.14.0 / 9.1.1 | ✅ |
| fastapi / uvicorn | 0.143.0 / 0.54.0 | ✅ 已装（阶段 5 用） |
| ortools | 9.14.6206 | ✅ 已装（并行会话完成安装） |
| **COPT / coptpy** | **8.0.6（完全重排后端，队长决策）** | ✅ 系统 Python 已配好；coptpy 包复制入项目 venv 验证通过 |

## 运行命令（Windows，均已实际执行）

```bat
cd C:\Users\tianj\Desktop\城配调度副驾
.venv\Scripts\python.exe -m pytest
.venv\Scripts\python.exe scripts\make_sample.py
.venv\Scripts\python.exe scripts\export_schema.py
.venv\Scripts\python.exe scripts\build_manifest.py
.venv\Scripts\python.exe scripts\build_scenarios.py
.venv\Scripts\python.exe scripts\solve_cli.py   :: 阶段 2 CLI
```

## 测试结果

- **142 passed in 1.36s**（`reports/review_fix_pytest_log.txt`）；阶段 4 后全量 **201 passed**
  （`reports/stage4_pytest_log.txt`，新增 `tests/test_llm_phase4.py` 51 项）
- 覆盖：阶段 0 契约校验、阶段 1（Solomon 解析/转换/生成器可复现/集合无交叉/原始文件哈希核对/Amazon 合成样本）、阶段 2（独立校验器手算预期、插单基线、完全重排、五种状态语义、proven_infeasible、锁冲突）、阶段 3（扰动指标、diff 固定词表、低扰动求解端到端、锁保持、选择规则、候选全部独立复核）、跨电脑审查回归（R01–R09：闭环目标/大 M/同车双路线/锁成员跨车/返回时刻/零值子回路/无 COPT 隔离/状态映射全表/预算传递）
- 修复前失败证据：`reports/review_p0p1_prefail_log.txt`（11 项失败）；修复后同批 18 项全过

## 跨电脑审查修复（2026-10-11，详情见 reports/review_closure.md）

1. **校验器**：E_SOL_DUP_VEHICLE（一车一路线）、相对顺序锁成员必须在锁指定车辆（E_SOL_REL_ORDER_LOCK）、E_SOL_RETURN_MISMATCH（声明返回时刻必须等于独立重算）。
2. **COPT 建模**：目标补返仓弧（与独立校验器同定义）；大 M 修正为 horizon+max_service+max_tau（推导入 docstring）；新增单商品流连通约束消除零耗子回路（修正前 MTZ 在 0 行驶+0 服务下会返回"最优空路线"，已实测复现）；路线提取加 visited/步数上限。
3. **pipeline**：COPT 改为延迟导入（无 COPT 环境 insert/low_disruption/OR-Tools 可用，显式选 rebuild 报可理解错误）；预算真实传入插单/低扰动枚举并记 elapsed_solve_ms/elapsed_validate_ms；OrtoolsOutcome 结构化（backend/termination/has_incumbent/status_detail），接受 MIP_FEASIBLE，验证拒绝显式标 validator_rejected；proven_infeasible 警告注明"仅对当前建模有效"。
4. **数据链**：manifest v1.1（时间单位措辞、canonical/mirror 分离、source_ref 如实标浮动分支、license_url/terms_url/license_status/redistributable=待确认、verification_scope 如实记录仅 C101 首行交叉核对）；新增 `scripts/check_base_fingerprint.py`（同族变体坐标+需求 J=1.0，划分已隔离）与 `scripts/download_solomon.py`（原始文件不随包，许可待确认）；归档 3 个旧划分遗留草稿（`_stale_20261011/`，含哈希，未删除）；CLI 写出场景时 pending_original_plan/materialized 不再冲突。
5. **一键审查**：`scripts/review_check.py`（有 COPT / --skip-copt 两模式均 pass）+ `scripts/exhaustive_check.py`（R01 穷举 5=5、R02 穷举 3=3）。
6. **快照**：修复前代码快照 `reports/snapshot_prefix_20261011.zip`（sha256 前缀 7491d6b7927cd533）。

## 阶段 1 产物与验收对照

| 验收项 | 结果 |
|---|---|
| 来源与合成字段可追踪 | ✅ `data/manifests/solomon_manifest.json`（11 个算例：镜像 URL + SINTEF 规范源 + sha256 + 许可 + 字段映射 + 转换规则） |
| 样本通过 schema 校验 | ✅ 17 个派生情景草稿全部过 `validate_draft` |
| 数据许可状态有记录 | ✅ Solomon 学术基准注明；Amazon CC BY-NC 4.0 记录于映射文档 |
| 测试集不被调参读取 | ✅ 按基础算例划分（split seed 20261010），`registry.json` 记录 split；同一算例派生不跨集（测试断言） |
| 同种子结果一致 | ✅ 测试断言哈希一致 |

## 阶段 2 产物与验收对照

- `src/validation/timetable.py` 独立校验器（重算时刻/容量/窗/返回/覆盖/锁定，不采信求解器）
- `src/solver/insert.py` 插单基线（枚举插入，不搬旧任务，不漏单）
- `src/solver/copt_core.py` **COPT MIP 完全重排后端**（MTZ 时间链，支持两类锁，状态映射 MIP_INFEASIBLE/TIMEOUT_WITH_SOL 等）
- `src/solver/ortools_core.py` OR-Tools CP 版（保留作对照与阶段 3 候选生成）
- `src/solver/original.py` 原计划生成 + 锁定落实（lock_ratio/seed 可复现）
- `src/solver/pipeline.py` 编排 + 五种状态语义
- `scripts/solve_cli.py` CLI 输出规范 JSON/时刻表/校验报告

| 验收项 | 结果 |
|---|---|
| 可行结果均被独立复核 | ✅ pipeline 统一走 `validate_solution` |
| 拒绝漏单 | ✅ 求解器输出覆盖核对 + E_SOL_MISSING_ORDER |
| 返回时间和等待正确 | ✅ 手算预期测试（300/420/620/740/1350 等逐项断言） |
| 超时没有被写成证明无解 | ✅ 10ms 预算测试断言 no_feasible_found 且 ≠ proven_infeasible |

## 阶段 3 产物与验收对照（低扰动重排与差异解释）

| 验收项 | 结果 |
|---|---|
| 扰动指标精确定义 | ✅ `src/solver/perturbation.py`：换车数只统计旧任务；相邻破坏按"滤去新任务后旧有序对是否仍同车相邻"判定，插入顺延不计 |
| 候选生成（不调用子求解） | ✅ `src/solver/low_disruption.py`：插单种子 → 失败时单旧任务搬动枚举种子 → 尊重锁的 relocate/swap 局部搜索；全程 `evaluate_route` 独立重算 |
| 选择规则 | ✅ best_cost = 候选池最低成本；低扰动 = 成本 ≤ 1.10×best_cost 中按 (换车, 相邻破坏, 成本) 字典序最小；候选不足两个如实 warning |
| 逐任务 diff | ✅ `src/solver/diff.py`：车辆/双索引（原始+旧任务内）+ 固定词表变更原因，全部程序生成 |
| 预算口径（审查修正 3） | ✅ 低扰动不调用 COPT/OR-Tools 子求解，elapsed 即端到端耗时；假设写入输出 assumptions |
| 三方法同输入对比 | ✅ `reports/stage3_smoke/`（insert 38540s / rebuild 28220s / low_disruption 推荐 33372s，候选 216 个） |
| 测试 | ✅ 13 个新测试（无新增零扰动/顺延不计/换车只算旧任务/两类锁保持/选择规则/候选全部独立复核），全量 124 passed |

## 重要工程决策（需队长知悉）

1. **完全重排后端采用 COPT 8.0.6（替代任务书中的 OR-Tools）**——理由（队长指示 + 技术必要性）：
   - OR-Tools CP 在"固定出发时刻"模型下 PATH_CHEAPEST_ARC 无法构造初解（实测 15 节点 20s 超时），已改 PARALLEL_CHEAPEST_INSERTION 修复；
   - OR-Tools CP 对不可行情形只返回 ROUTING_FAIL，**无法可靠给出"证明无解"**（任务书要求区分 proven_infeasible）；COPT MIP 可证明不可行；
   - OR-Tools 版保留（`backend="ortools"` 可选，阶段 3 候选生成可用）。
2. **ortools_core 移除 drop 析取**：原实现给所有节点加丢弃惩罚，导致模型永不不可行、超时也能秒出"全丢弃"假解，直接违反"不得丢单"红线。
3. **SolutionValidation.issues 现汇总路线级+方案级全部违规**（测试红线要求一处可见）。
4. coptpy 以复制方式进入项目 venv（系统 site-packages → .venv），因 pip 下载大 wheel 在本机网络反复超时；COPT 本体与 license 为机器全局配置（`C:\Program Files\copt80`、`C:\Users\tianj\copt\license.dat`）。**换机运行需重装 COPT 或改回 OR-Tools 后端**（已留开关）。

## 已知风险 / 未完成

1. COPT 求解日志已关闭（Logging=0）；诊断时可在调用层打开。
2. `travel_seconds()` 冗余函数未清理（无害）；`build_travel_matrix` 中未使用变量 `idx`。
3. Git 仓库仍未初始化（等队长指示）。

## 下一阶段所需输入

- 阶段 4（评测与报告，任务书第 13 章）：三方法在 dev/test 集合上的批量评测、指标表与结论。方法接口已齐（insert/rebuild/low_disruption），批量 runner 可复用 `scripts/solve_cli.py` 或直接在 pipeline 上循环。

## 待决定事项

- 是否初始化 Git 仓库；
- COPT 作为默认后端是否写进交付 README（涉及比赛环境是否有 COPT 许可——若没有，评测机需回退 OR-Tools 后端，属交付时必须交代的限制）。
